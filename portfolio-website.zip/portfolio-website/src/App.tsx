import { useEffect, useRef, useState, type ElementType, type MouseEvent } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'

const marqueeImages = [
  'https://motionsites.ai/assets/hero-space-voyage-preview-eECLH3Yc.gif',
  'https://motionsites.ai/assets/hero-codenest-preview-Cgppc2qV.gif',
  'https://motionsites.ai/assets/hero-vex-ventures-preview-BczMFIiw.gif',
  'https://motionsites.ai/assets/hero-stellar-ai-v2-preview-DjvxjG3C.gif',
  'https://motionsites.ai/assets/hero-asme-preview-B_nGDnTP.gif',
  'https://motionsites.ai/assets/hero-transform-data-preview-Cx5OU29N.gif',
  'https://motionsites.ai/assets/hero-vitara-preview-Cjz2QYyU.gif',
  'https://motionsites.ai/assets/hero-terra-preview-BFjrCr7T.gif',
  'https://motionsites.ai/assets/hero-skyelite-preview-DHaZIgUv.gif',
  'https://motionsites.ai/assets/hero-aethera-preview-DknSlcTa.gif',
  'https://motionsites.ai/assets/hero-designpro-preview-D8c5_een.gif',
  'https://motionsites.ai/assets/hero-stellar-ai-preview-D3HL6bw1.gif',
  'https://motionsites.ai/assets/hero-xportfolio-preview-D4A8maiC.gif',
  'https://motionsites.ai/assets/hero-orbit-web3-preview-BXt4OttD.gif',
  'https://motionsites.ai/assets/hero-nexora-preview-cx5HmUgo.gif',
  'https://motionsites.ai/assets/hero-evr-ventures-preview-DZxeVFEX.gif',
  'https://motionsites.ai/assets/hero-planet-orbit-preview-DWAP8Z1P.gif',
  'https://motionsites.ai/assets/hero-new-era-preview-CocuDUm9.gif',
  'https://motionsites.ai/assets/hero-wealth-preview-B70idl_u.gif',
  'https://motionsites.ai/assets/hero-luminex-preview-CxOP7ce6.gif',
  'https://motionsites.ai/assets/hero-celestia-preview-0yO3jXO8.gif',
]

const projects = [
  {
    no: '01', category: 'Client', name: 'Nextlevel Studio',
    imgs: [
      'https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20260412_055344_5eff02e0-87a5-41ce-b64f-eb08da8f33db.png&w=1280&q=85',
      'https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20260412_055431_11d841fd-8b41-46a5-82e4-b04f2407a7d8.png&w=1280&q=85',
      'https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20260412_055451_e317bf2d-28d4-48cc-86b0-6f72f25b6327.png&w=1280&q=85',
    ]
  },
  {
    no: '02', category: 'Personal', name: 'Aura Brand Identity',
    imgs: [
      'https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20260412_055654_911201c5-36d9-4bc6-bac7-331adfce159f.png&w=1280&q=85',
      'https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20260412_055723_5ceda0b8-d9c2-4665-b2e3-83ba19ba76d1.png&w=1280&q=85',
      'https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20260412_055753_adc5dcbd-a8e6-49c0-b43a-9b030d835cea.png&w=1280&q=85',
    ]
  },
  {
    no: '03', category: 'Client', name: 'Solaris Digital',
    imgs: [
      'https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20260412_055759_963cfb0b-4bd1-4b0f-9d0a-09bd6cf95b2f.png&w=1280&q=85',
      'https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20260412_060108_438f781a-9846-4dcc-89ab-c4e6cb830f5b.png&w=1280&q=85',
      'https://images.higgs.ai/?default=1&output=webp&url=https%3A%2F%2Fd8j0ntlcm91z4.cloudfront.net%2Fuser_38xzZboKViGWJOttwIXH07lWA1P%2Fhf_20260412_055818_9d062121-ad7e-46b9-999a-1a6a692ef1ee.png&w=1280&q=85',
    ]
  }
]

const services = [
  ['01','3D Modeling','Creation of detailed objects, characters, or environments tailored to specific client needs, ideal for games, products, and visualizations.'],
  ['02','Rendering','High-quality, photorealistic renders that showcase designs with custom lighting, textures, and materials to bring concepts to life.'],
  ['03','Motion Design','Dynamic animations and motion graphics that add energy and storytelling to brands, products, and digital experiences.'],
  ['04','Branding','Crafting cohesive visual identities -- from logos to full brand systems -- that communicate a clear and memorable presence.'],
  ['05','Web Design','Designing clean, modern, and conversion-focused websites with attention to layout, typography, and user experience.'],
]

function FadeIn({children, delay=0, duration=.7, x=0, y=30, as='div', className=''}:{children:React.ReactNode,delay?:number,duration?:number,x?:number,y?:number,as?:ElementType,className?:string}){
  const M = motion.create(as)
  return <M className={className} initial={{opacity:0,x,y}} whileInView={{opacity:1,x:0,y:0}} viewport={{once:true,margin:'50px',amount:0}} transition={{duration,delay,ease:[.25,.1,.25,1]}}>{children}</M>
}

function ContactButton(){
  return <button className="rounded-full px-8 py-3 sm:px-10 sm:py-3.5 md:px-12 md:py-4 text-xs sm:text-sm md:text-base font-medium uppercase tracking-widest text-white outline outline-2 outline-white outline-offset-[-3px] transition-transform hover:scale-105" style={{background:'linear-gradient(123deg,#18011F 7%,#B600A8 37%,#7621B0 72%,#BE4C00 100%)',boxShadow:'0 4px 4px rgba(181,1,167,.25),4px 4px 12px #7721B1 inset'}}>Contact Me</button>
}

function Magnet({children}:{children:React.ReactNode}){
  const ref = useRef<HTMLDivElement>(null)
  const [style,setStyle]=useState({transform:'translate3d(0,0,0)',transition:'transform .6s ease-in-out'})
  const move=(e:MouseEvent<HTMLDivElement>)=>{const r=ref.current?.getBoundingClientRect();if(!r)return;const x=(e.clientX-(r.left+r.width/2))/3;const y=(e.clientY-(r.top+r.height/2))/3;setStyle({transform:`translate3d(${x}px,${y}px,0)`,transition:'transform .3s ease-out'})}
  return <div ref={ref} onMouseMove={move} onMouseLeave={()=>setStyle({transform:'translate3d(0,0,0)',transition:'transform .6s ease-in-out'})} style={{...style,willChange:'transform'}}>{children}</div>
}

function Marquee(){
  const ref=useRef<HTMLElement>(null); const [offset,setOffset]=useState(0)
  useEffect(()=>{const on=()=>{if(!ref.current)return;setOffset((window.scrollY-ref.current.offsetTop+window.innerHeight)*.3)};on();window.addEventListener('scroll',on,{passive:true});return()=>window.removeEventListener('scroll',on)},[])
  const row=(arr:string[],dir:number)=><div className="flex gap-3 w-max" style={{transform:`translateX(${dir*(offset-200)}px)`,willChange:'transform'}}>{[...arr,...arr,...arr].map((s,i)=><img key={i} src={s} loading="lazy" className="w-[420px] h-[270px] rounded-2xl object-cover" />)}</div>
  return <section ref={ref} className="bg-[#0C0C0C] pt-24 sm:pt-32 md:pt-40 pb-10 overflow-hidden space-y-3">{row(marqueeImages.slice(0,11),1)}{row(marqueeImages.slice(11),-1)}</section>
}

function ProjectCard({p,index}:{p:typeof projects[number],index:number}){
  const ref=useRef<HTMLDivElement>(null); const {scrollYProgress}=useScroll({target:ref,offset:['start end','end start']}); const scale=useTransform(scrollYProgress,[0,1],[1,1-(projects.length-1-index)*.03])
  return <div ref={ref} className="h-[85vh]"><motion.article style={{scale,top:`calc(6rem + ${index*28}px)`}} className="sticky rounded-[40px] sm:rounded-[50px] md:rounded-[60px] border-2 border-[#D7E2EA] bg-[#0C0C0C] p-4 sm:p-6 md:p-8 overflow-hidden">
    <div className="flex flex-wrap items-end justify-between gap-4 mb-5"><div className="text-[clamp(3rem,10vw,8rem)] font-black leading-none">{p.no}</div><div className="uppercase tracking-widest opacity-60">{p.category}</div><h3 className="text-[clamp(1.5rem,4vw,4rem)] uppercase font-semibold">{p.name}</h3><button className="rounded-full border-2 border-[#D7E2EA] px-6 py-3 uppercase tracking-widest hover:bg-[#D7E2EA]/10">Live Project</button></div>
    <div className="grid grid-cols-1 md:grid-cols-[40%_60%] gap-3"><div className="space-y-3"><img src={p.imgs[0]} className="w-full h-[clamp(130px,16vw,230px)] object-cover rounded-[40px] sm:rounded-[50px] md:rounded-[60px]"/><img src={p.imgs[1]} className="w-full h-[clamp(160px,22vw,340px)] object-cover rounded-[40px] sm:rounded-[50px] md:rounded-[60px]"/></div><img src={p.imgs[2]} className="w-full h-full min-h-[360px] object-cover rounded-[40px] sm:rounded-[50px] md:rounded-[60px]"/></div>
  </motion.article></div>
}

export default function App(){
  return <main className="bg-[#0C0C0C] overflow-x-clip">
    <section className="h-screen relative flex flex-col overflow-x-clip px-6 md:px-10">
      <FadeIn y={-20}><nav className="flex justify-between pt-6 md:pt-8 text-sm md:text-lg lg:text-[1.4rem] font-medium uppercase tracking-wider text-[#D7E2EA]">{['About','Price','Projects','Contact'].map(x=><a key={x} href={`#${x.toLowerCase()}`} className="hover:opacity-70 transition-opacity">{x}</a>)}</nav></FadeIn>
      <FadeIn delay={.15} y={40} className="overflow-hidden"><h1 className="hero-heading mt-6 sm:mt-4 md:-mt-5 text-[14vw] sm:text-[15vw] md:text-[16vw] lg:text-[17.5vw] font-black uppercase tracking-tight leading-none whitespace-nowrap w-full">Hi, i&apos;m jack</h1></FadeIn>
      <FadeIn delay={.6} y={30} className="absolute left-1/2 -translate-x-1/2 z-10 top-1/2 -translate-y-1/2 sm:top-auto sm:translate-y-0 sm:bottom-0 w-[280px] sm:w-[360px] md:w-[440px] lg:w-[520px]"><Magnet><img src="https://shrug-person-78902957.figma.site/_components/v2/d24c01ad3a56fc65e942a1f501eb73db42d7cf9a/Rectangle_40443.81459862.png" className="w-full"/></Magnet></FadeIn>
      <div className="mt-auto flex justify-between items-end pb-7 sm:pb-8 md:pb-10 relative z-20"><FadeIn delay={.35} y={20}><p className="text-[#D7E2EA] font-light uppercase tracking-wide leading-snug max-w-[160px] sm:max-w-[220px] md:max-w-[260px]" style={{fontSize:'clamp(.75rem,1.4vw,1.5rem)'}}>a 3d creator driven by crafting striking and unforgettable projects</p></FadeIn><FadeIn delay={.5} y={20}><ContactButton/></FadeIn></div>
    </section>
    <Marquee/>
    <section id="about" className="relative min-h-screen px-5 sm:px-8 md:px-10 py-20 flex items-center justify-center overflow-hidden">
      {[
        ['https://shrug-person-78902957.figma.site/_components/v2/ebb2b8f25d8e24d5f0a5ca8af4c950de81aa2fd7/moon_icon.11395d36.png','top-[4%] left-[1%] sm:left-[2%] md:left-[4%] w-[120px] sm:w-[160px] md:w-[210px]'],
        ['https://shrug-person-78902957.figma.site/_components/v2/ebb2b8f25d8e24d5f0a5ca8af4c950de81aa2fd7/p59_1.4659672e.png','bottom-[8%] left-[3%] sm:left-[6%] md:left-[10%] w-[100px] sm:w-[140px] md:w-[180px]'],
        ['https://shrug-person-78902957.figma.site/_components/v2/ebb2b8f25d8e24d5f0a5ca8af4c950de81aa2fd7/lego_icon-1.703bb594.png','top-[4%] right-[1%] sm:right-[2%] md:right-[4%] w-[120px] sm:w-[160px] md:w-[210px]'],
        ['https://shrug-person-78902957.figma.site/_components/v2/ebb2b8f25d8e24d5f0a5ca8af4c950de81aa2fd7/Group_134-1.2e04f3ce.png','bottom-[8%] right-[3%] sm:right-[6%] md:right-[10%] w-[130px] sm:w-[170px] md:w-[220px]']
      ].map(([s,c],i)=><FadeIn key={s} delay={.1+i*.05} x={i<2?-80:80} y={0} duration={.9} className={`absolute ${c}`}><img src={s} className="w-full"/></FadeIn>)}
      <div className="relative z-10 flex flex-col items-center gap-10 sm:gap-14 md:gap-16 text-center"><FadeIn><h2 className="hero-heading font-black uppercase leading-none tracking-tight" style={{fontSize:'clamp(3rem,12vw,160px)'}}>About me</h2></FadeIn><FadeIn delay={.15}><p className="max-w-[560px] text-[#D7E2EA] font-medium leading-relaxed" style={{fontSize:'clamp(1rem,2vw,1.35rem)'}}>With more than five years of experience in design, i focus on branding, web design, and user experience, i truly enjoy working with businesses that aim to stand out and present their best image. Let&apos;s build something incredible together!</p></FadeIn><div className="pt-6 sm:pt-10 md:pt-12"><ContactButton/></div></div>
    </section>
    <section id="price" className="bg-white text-[#0C0C0C] rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] px-5 sm:px-8 md:px-10 py-20 sm:py-24 md:py-32"><h2 className="font-black uppercase text-center mb-16 sm:mb-20 md:mb-28" style={{fontSize:'clamp(3rem,12vw,160px)'}}>Services</h2><div className="max-w-5xl mx-auto">{services.map((s,i)=><FadeIn key={s[0]} delay={i*.1} className="grid grid-cols-[auto_1fr] gap-6 sm:gap-10 items-start border-t border-black/15 py-8 sm:py-10 md:py-12 last:border-b"><div className="font-black leading-none" style={{fontSize:'clamp(3rem,10vw,140px)'}}>{s[0]}</div><div className="pt-2"><h3 className="font-medium uppercase mb-3" style={{fontSize:'clamp(1rem,2.2vw,2.1rem)'}}>{s[1]}</h3><p className="font-light leading-relaxed max-w-2xl opacity-60" style={{fontSize:'clamp(.85rem,1.6vw,1.25rem)'}}>{s[2]}</p></div></FadeIn>)}</div></section>
    <section id="projects" className="relative z-10 bg-[#0C0C0C] rounded-t-[40px] sm:rounded-t-[50px] md:rounded-t-[60px] -mt-10 sm:-mt-12 md:-mt-14 px-5 sm:px-8 md:px-10 py-20 sm:py-24 md:py-32"><h2 className="hero-heading font-black uppercase text-center mb-16" style={{fontSize:'clamp(3rem,12vw,160px)'}}>Project</h2><div className="max-w-7xl mx-auto">{projects.map((p,i)=><ProjectCard key={p.no} p={p} index={i}/>)}</div></section>
  </main>
}
